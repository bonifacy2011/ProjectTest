package com.pleshak.contact.action;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.pleshak.contact.db.ConnectionDB;
import com.pleshak.contact.domain.Contact;

public class ContactList {

	private static final String SELECT_ALL_CONTACTS_SQL = "SELECT * FROM contact.contacts LIMIT 0,10";
	private static final String SELECT_ALL_CONTACTS_SQL_ORDER_BY_NAME = "SELECT * FROM contact.contacts ORDER BY name LIMIT 0,10";
	private static final String SELECT_ALL_CONTACTS_SQL_ORDER_BY_NAME_DESC = "SELECT * FROM contact.contacts ORDER BY name DESC LIMIT 0,10";

	private ArrayList<Contact> getContacts(String sql) {

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection conn = null;
		ArrayList<Contact> contactList = new ArrayList<Contact>();
		try {
			conn = ConnectionDB.getConnection();
			// Class.forName("com.mysql.jdbc.Driver");
			// conn =
			// DriverManager.getConnection("jdbc:mysql://localhost:3306/contact",
			// "root", "708802611297088026");
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Contact contact = new Contact();
				contact.setId(rs.getInt("id"));
				contact.setName(rs.getString("name"));
				contact.setSurname(rs.getString("surname"));
				contact.setLogin(rs.getString("login"));
				contact.setEmail(rs.getString("email"));
				contact.setPhoneNumber(rs.getInt("phone_number"));

				contactList.add(contact);
				System.out.print(contact.getId() + "  ");
				System.out.println(contact.getName());
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionDB.closeDbResources(conn, pstmt, rs);
		}

		return contactList;

	}

	public ArrayList<Contact> getAllContacts() {

		return getContacts(SELECT_ALL_CONTACTS_SQL);

	}

	public ArrayList<Contact> getOrderByNameContactsAZ() {// sort by a-z

		return getContacts(SELECT_ALL_CONTACTS_SQL_ORDER_BY_NAME);

	}

	public ArrayList<Contact> getOrderByNameContactsZA() {// sort by z-a

		return getContacts(SELECT_ALL_CONTACTS_SQL_ORDER_BY_NAME_DESC);

	}
}
