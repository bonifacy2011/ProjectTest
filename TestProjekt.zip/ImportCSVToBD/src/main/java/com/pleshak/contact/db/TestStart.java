package com.pleshak.contact.db;

import com.pleshak.contact.action.ContactList;
import com.pleshak.contact.action.UploadFile;

public class TestStart {

	public static void main(String[] args) {

		UploadFile uf = new UploadFile();
		// uf.setContacts("c:/In.csv");

		ContactList cl = new ContactList();
		cl.getAllContacts();
		cl.getOrderByNameContactsAZ();
		cl.getOrderByNameContactsZA();
	}
}